package com.rakuten.gap.ads.mission_core.status

/**
 * Login Option type
 */
enum class RakutenRewardTokentype {
    /**
     * Rakuten ID SDK, use API token for SDK.
     */
    RID,

    /**
     * Rakuten User SDK, use token for SDK.
     */
    @Deprecated("RAE will be sunset. Please make a plan to migrate to RID token or other solution. This enum entry will be removed in the next release.")
    RAE,

    /**
     * Default login option. Reward SDk provide login API and handle token renewal.
     */
    RAKUTEN_AUTH
}