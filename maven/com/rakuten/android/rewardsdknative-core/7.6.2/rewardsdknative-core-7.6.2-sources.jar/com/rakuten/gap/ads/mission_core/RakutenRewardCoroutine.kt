package com.rakuten.gap.ads.mission_core

import com.rakuten.gap.ads.mission_core.data.MissionAchievementData
import com.rakuten.gap.ads.mission_core.data.MissionData
import com.rakuten.gap.ads.mission_core.data.MissionLiteData
import com.rakuten.gap.ads.mission_core.data.RakutenRewardPointHistory
import com.rakuten.gap.ads.mission_core.data.RakutenRewardUser
import com.rakuten.gap.ads.mission_core.data.redeem.LinkShareItemPointHistory
import com.rakuten.gap.ads.mission_core.data.redeem.RewardRedeemRequest
import com.rakuten.gap.ads.mission_core.di.ContainerProvider
import com.rakuten.gap.ads.mission_core.modules.ModuleProvider
import com.rakuten.gap.ads.mission_core.status.RakutenRewardConsentStatus
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

/**
 * This class contains API of Reward SDK in Coroutines
 */
object RakutenRewardCoroutine {

    /**
     * Get the latest member info
     *
     * @return [RakutenRewardUser] for success case
     */
    @JvmStatic
    suspend fun memberInfo(): RewardApiResult<RakutenRewardUser> =
        getModuleProvider().provideMembersCoroutineModule().memberInfo()

    /**
     * Get the mission list
     *
     * @return list of [MissionData] for success case
     */
    @JvmStatic
    suspend fun getMissions(): RewardApiResult<List<MissionData>> =
        getModuleProvider().provideMissionCoroutineModule().getMissionList()

    /**
     * Get the mission list lite
     *
     * @return list of [MissionData] for success case
     */
    @JvmStatic
    suspend fun getMissionsLite(): RewardApiResult<List<MissionLiteData>> =
        getModuleProvider().provideMissionCoroutineModule().getMissionLite()

    /**
     * Get the mission details
     *
     * @return [MissionData] for success case
     */
    @JvmStatic
    suspend fun getMissionDetails(actionCode: String): RewardApiResult<MissionData> =
        getModuleProvider().provideMissionCoroutineModule().getMissionDetails(actionCode = actionCode)

    /**
     * Log a mission action
     *
     * @param [actionCode] The action code of the mission
     */
    @JvmStatic
    suspend fun logAction(actionCode: String): RewardApiResult<Unit> =
        getModuleProvider().provideMissionCoroutineModule().logAction(actionCode)

    /**
     * Get user's last 3 months point history
     *
     * @return [RakutenRewardPointHistory] for success case
     */
    @JvmStatic
    suspend fun getPointHistory(): RewardApiResult<RakutenRewardPointHistory> =
        getModuleProvider().providePointCoroutineModule().pointHistory()

    /**
     * Request for consent
     *
     * <mark> Internal Use only </mark>
     */
    @JvmStatic
    internal suspend fun requestForConsent(): RakutenRewardConsentStatus {
        return suspendCoroutine { continuation ->
            RakutenReward.requestForConsent {
                continuation.resume(it)
            }
        }
    }

    /**
     * Get the list of unclaimed items
     *
     * @return list of unclaimed [MissionAchievementData] for success case
     */
    @JvmStatic
    suspend fun getUnclaimedItems(): RewardApiResult<List<MissionAchievementData>> =
        getModuleProvider().provideUnclaimCoroutineModule().getUnclaim()

    @JvmStatic
    suspend fun getLSPointHistory(redeemRequest: RewardRedeemRequest, offset: Int, limit: Int): RewardApiResult<LinkShareItemPointHistory> =
        getModuleProvider().provideRedeemCoroutineModule().getLinkShareItemPointHistory(redeemRequest, "", offset, limit)

    /**
     * Get LinkShare item point history by status
     *
     * @param redeemRequest The redeem request information
     * @param status The status filter for point history - "PROCESSING", "SUCCESS"
     * @param offset The offset for pagination
     * @param limit The limit for pagination
     * @return [LinkShareItemPointHistory] for success case
     */
    @JvmStatic
    suspend fun getLSPointHistoryByStatus(redeemRequest: RewardRedeemRequest, status: String, offset: Int, limit: Int): RewardApiResult<LinkShareItemPointHistory> =
        getModuleProvider().provideRedeemCoroutineModule().getLinkShareItemPointHistory(redeemRequest, status, offset, limit)

    @JvmStatic
    suspend fun getLSProcessingPoint(redeemRequest: RewardRedeemRequest): RewardApiResult<Int> =
        getModuleProvider().provideRedeemCoroutineModule().getLinkShareProcessingPoint(redeemRequest)

    private fun getModuleProvider(): ModuleProvider {
        return ContainerProvider.getAppContainer().getProvider(ModuleProvider::class.java)
    }
}