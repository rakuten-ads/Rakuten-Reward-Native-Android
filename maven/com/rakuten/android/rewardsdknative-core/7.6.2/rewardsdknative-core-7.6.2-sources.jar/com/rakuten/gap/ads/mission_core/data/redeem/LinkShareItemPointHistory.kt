package com.rakuten.gap.ads.mission_core.data.redeem

/**
 * This is LinkShare Item Affiliate Point history data
 *
 * @property total Total number of point history records
 * @property offset The offset of the current page
 * @property limit The maximum number of records per page
 * @property history List of [LinkShareItemPoint] records
 */
data class LinkShareItemPointHistory(
    val total: Int,
    val offset: Int,
    val limit: Int,
    val history: List<LinkShareItemPoint>
)

/**
 * This is LinkShare Item Affiliate Point record
 *
 * @property point The number of points earned
 * @property advertiserId The advertiser ID associated with the transaction
 * @property advertiserName The advertiser associated with the transaction
 * @property grantDate The date when the points were granted in yyyy-MM-dd format
 * @property transactionDate The date of the transaction that earned the points in yyyy-MM-dd format
 * @property orderId The order ID associated with the transaction
 * @property isPointGranted Indicates whether the points have been granted
 */
data class LinkShareItemPoint(
    val point: Int,
    val advertiserId: Long,
    val advertiserName: String,
    val grantDate: String,
    val transactionDate: String,
    val orderId: String,
    val isPointGranted: Boolean
)
