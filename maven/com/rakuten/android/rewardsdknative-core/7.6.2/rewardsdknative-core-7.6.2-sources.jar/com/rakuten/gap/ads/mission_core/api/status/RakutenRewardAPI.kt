package com.rakuten.gap.ads.mission_core.api.status

/**
 * Enumeration class for Reward SDK API
 */
enum class RakutenRewardAPI {
    /**
     * Member Info API
     */
    MEMBERINFO,

    /**
     * Log Mission Action API
     */
    LOGACTION,

    /**
     * Get unclaimed items API
     */
    GETUNCLAIM,

    /**
     * Get user's point history API
     */
    POINTHISTORY,

    /**
     * Claim Point API
     */
    CLAIM,

    /**
     * Get mission list API
     */
    GETMISSIONLIST,

    /**
     * Get mission list lite API
     */
    GETMISSIONLISTLITE,

    /**
     * Get mission Details API
     */
    GETMISSIONDETAILS,

    /**
     * Provide Consent API
     */
    PROVIDE_CONSENT,

    /**
     * Redeem Reward History API
     */
    REDEEM_HISTORY,

    /**
     * Redeem Reward Count API
     */
    REDEEM_COUNT,
}