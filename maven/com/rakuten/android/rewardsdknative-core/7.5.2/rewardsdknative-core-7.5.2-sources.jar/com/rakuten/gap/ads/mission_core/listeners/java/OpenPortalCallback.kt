package com.rakuten.gap.ads.mission_core.listeners.java

import com.rakuten.gap.ads.mission_core.api.status.RakutenRewardAPIError

/**
 * Open Portal callback
 */
interface OpenPortalCallback {

    /**
     * Success callback
     */
    fun success()

    /**
     * Failure callback
     */
    fun failed(e: RakutenRewardAPIError)
}