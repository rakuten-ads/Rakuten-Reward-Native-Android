package com.rakuten.gap.ads.mission_core.listeners

/**
 *
 * @author zack.keng
 * Created on 2024/04/12
 * Copyright © 2024 Rakuten Asia. All rights reserved.
 */
interface PreClaimCallback {
    fun proceedClaim()
}