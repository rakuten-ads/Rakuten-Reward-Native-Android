package com.rakuten.gap.ads.mission_core.listeners.java

import com.rakuten.gap.ads.mission_core.api.status.RakutenRewardAPIError
import com.rakuten.gap.ads.mission_core.data.RakutenAuthUserInfo

/**
 * Get user latest Rakuten Points and Rank callback
 */
interface AuthMemberInfoCallback {

    /**
     * Success callback
     *
     * @param [userInfo] User latest Rakuten Points and Rank data
     */
    fun success(userInfo: RakutenAuthUserInfo)

    /**
     * Failure callback
     */
    fun fail(e: RakutenRewardAPIError)
}