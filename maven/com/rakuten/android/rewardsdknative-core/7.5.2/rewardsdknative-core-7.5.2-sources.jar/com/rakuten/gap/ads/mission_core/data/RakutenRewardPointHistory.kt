package com.rakuten.gap.ads.mission_core.data

/**
 * This is Reward SDK point history data
 */
data class RakutenRewardPointHistory(val history: List<RakutenRewardPoint>)