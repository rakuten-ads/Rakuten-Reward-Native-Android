package com.rakuten.gap.ads.mission_core.listeners.java

import com.rakuten.gap.ads.mission_core.api.status.RakutenRewardAPIError

/**
 * Log mission action callback
 */
interface LogActionCallback {
    /**
     * Success callback
     */
    fun success()

    /**
     * Failure callback
     */
    fun fail(e: RakutenRewardAPIError)
}