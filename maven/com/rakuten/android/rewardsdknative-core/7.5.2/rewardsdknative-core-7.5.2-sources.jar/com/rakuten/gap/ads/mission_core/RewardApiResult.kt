package com.rakuten.gap.ads.mission_core

import com.rakuten.gap.ads.mission_core.api.status.RakutenRewardAPIError

/**
 * RewardApiResult sealed class
 */
sealed class RewardApiResult<T>

/**
 * Success RewardApiResult
 *
 * @param [data] API data
 */
data class Success<T>(val data: T) : RewardApiResult<T>()

/**
 * Failed RewardApiResult
 *
 * @param [error] Error code
 */
data class Failed<T>(val error: RakutenRewardAPIError) : RewardApiResult<T>()