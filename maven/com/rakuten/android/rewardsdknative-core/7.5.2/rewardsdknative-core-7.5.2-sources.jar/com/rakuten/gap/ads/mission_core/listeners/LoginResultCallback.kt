package com.rakuten.gap.ads.mission_core.listeners

import com.rakuten.gap.ads.mission_core.api.status.RakutenRewardAPIError

/**
 * Log In result callback
 */
interface LoginResultCallback {
    /**
     * Logged in successfully
     */
    fun loginSuccess()

    /**
     * Log in failed
     */
    fun loginFailed(e: RakutenRewardAPIError)
}