package com.rakuten.gap.ads.mission_core.listeners.java

import com.rakuten.gap.ads.mission_core.api.status.RakutenRewardAPIError
import com.rakuten.gap.ads.mission_core.data.MissionLiteData

/**
 * Get mission list callback
 */
interface GetMissionsLiteCallback {
    /**
     * Success callback
     *
     * @param [missions] list of MissionLiteData object
     */
    fun success(missions: List<MissionLiteData>)

    /**
     * Failure callback
     */
    fun fail(e: RakutenRewardAPIError)
}