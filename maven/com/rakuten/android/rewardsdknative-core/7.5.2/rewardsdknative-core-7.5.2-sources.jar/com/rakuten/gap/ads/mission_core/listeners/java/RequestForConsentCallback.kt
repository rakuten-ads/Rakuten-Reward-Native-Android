package com.rakuten.gap.ads.mission_core.listeners.java

import com.rakuten.gap.ads.mission_core.status.RakutenRewardConsentStatus

/**
 * Request for consent callback
 *
 * @author zack.keng
 * Created on 2023/05/09
 */
interface RequestForConsentCallback {

    /**
     * On consent provided callback
     */
    fun onRequestConsentResult(status: RakutenRewardConsentStatus)
}
