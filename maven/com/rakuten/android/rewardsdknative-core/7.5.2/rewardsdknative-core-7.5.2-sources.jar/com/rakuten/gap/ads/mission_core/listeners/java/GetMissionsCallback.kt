package com.rakuten.gap.ads.mission_core.listeners.java

import com.rakuten.gap.ads.mission_core.api.status.RakutenRewardAPIError
import com.rakuten.gap.ads.mission_core.data.MissionData

/**
 * Get mission list callback
 */
interface GetMissionsCallback {
    /**
     * Success callback
     *
     * @param [missions] list of MissionData object
     */
    fun success(missions: List<MissionData>)

    /**
     * Failure callback
     */
    fun fail(e: RakutenRewardAPIError)
}