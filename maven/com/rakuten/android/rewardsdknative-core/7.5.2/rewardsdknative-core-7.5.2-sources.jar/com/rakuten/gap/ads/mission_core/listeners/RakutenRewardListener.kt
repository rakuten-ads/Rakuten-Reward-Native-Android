package com.rakuten.gap.ads.mission_core.listeners

import com.rakuten.gap.ads.mission_core.api.status.RakutenRewardClaimStatus
import com.rakuten.gap.ads.mission_core.data.MissionAchievementData
import com.rakuten.gap.ads.mission_core.data.RakutenRewardUser
import com.rakuten.gap.ads.mission_core.status.RakutenRewardSDKStatus

/**
 * Rakuten Reward Basic function event callback
 */
interface RakutenRewardListener {

    /**
     * User achieved a mission. This is mainly used for CUSTOM notification type
     */
    fun onUnclaimedAchievement(achievement: MissionAchievementData)

    /**
     * User data is updated
     */
    fun onUserUpdated(user: RakutenRewardUser)

    /**
     * Reward SDK status is changed
     */
    fun onSDKStatusChanged(status: RakutenRewardSDKStatus)

    /**
     * Claim view is closed
     */
    fun onSDKClaimClosed(
        missionAchievementData: MissionAchievementData,
        status: RakutenRewardClaimStatus
    )

    /**
     * User Consent view is closed
     */
    fun onSDKConsentClosed()

    /**
     * User Consent view is presented
     *
     * @since 5.4.0
     */
    fun onSDKConsentPresented()

    /**
     * Claim view is presented
     *
     * @since 5.4.0
     */
    fun onSDKClaimPresented(missionAchievementData: MissionAchievementData)
}
