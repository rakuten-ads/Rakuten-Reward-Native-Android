package com.rakuten.gap.ads.mission_core.data

/**
 * This is Reward SDK Point data
 */
data class RakutenRewardPoint(
    /**
     * Point data
     */
    val point: Int,
    /**
     * Point date month in yyyyMM format
     */
    val pointdate: String
)