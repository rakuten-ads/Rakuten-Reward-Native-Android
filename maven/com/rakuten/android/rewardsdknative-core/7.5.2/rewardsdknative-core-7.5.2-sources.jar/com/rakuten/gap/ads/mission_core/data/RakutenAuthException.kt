package com.rakuten.gap.ads.mission_core.data

internal sealed class RakutenAuthException : Exception()

internal class AuthInvalidRequestException : RakutenAuthException()
internal class AuthTimeoutException : RakutenAuthException()