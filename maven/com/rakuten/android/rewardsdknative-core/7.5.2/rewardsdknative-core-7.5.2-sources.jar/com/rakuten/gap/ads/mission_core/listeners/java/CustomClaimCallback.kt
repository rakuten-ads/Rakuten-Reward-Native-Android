package com.rakuten.gap.ads.mission_core.listeners.java

import com.rakuten.gap.ads.mission_core.api.status.RakutenRewardAPIError
import com.rakuten.gap.ads.mission_core.data.MissionAchievementData

/**
 * Claim point callback for CUSTOM notification type
 */
interface CustomClaimCallback {

    /**
     * Success callback
     */
    fun success(missionData: MissionAchievementData)

    /**
     * Failure callback
     */
    fun fail(e: RakutenRewardAPIError)
}