package com.rakuten.gap.ads.mission_core.data

import com.rakuten.gap.ads.mission_core.api.status.RakutenRewardAPI

/**
 * Last failed API call data information
 */
data class RakutenRewardAPILastCalled(
    /**
     * Last failed API enum
     */
    val method: RakutenRewardAPI,
    /**
     * Parameters for the API call
     * <table>
     *     <tr>
     *         <th>RakutenRewardAPI</th>
     *         <th>Parameter Key</th>
     *         <th>Parameter Value</th>
     *     </tr>
     *     <tr>
     *         <td>CLAIM</td>
     *         <td>mission</td>
     *         <td>MissionAchievementData object</td>
     *     </tr>
     *     <tr>
     *         <td>LOGACTION</td>
     *         <td>actionCode</td>
     *         <td>Mission Action Code String</td>
     *     </tr>
     * </table>
     */
    val parameters: Map<String, Any>
)