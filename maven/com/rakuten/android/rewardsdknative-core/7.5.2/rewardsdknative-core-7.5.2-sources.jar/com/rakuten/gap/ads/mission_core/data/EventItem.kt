package com.rakuten.gap.ads.mission_core.data

import com.rakuten.gap.ads.mission_core.modules.singleton.RewardSDKApiInfoModule

/**
 * @suppress
 *
 * @author zack.keng
 * Created on 2023/09/14
 * Copyright © 2023 Rakuten Asia. All rights reserved.
 */
data class EventItem(
    val eventKey: String,
    val appCode: String,
    val clientTimestamp: Long,
    private val extra: MutableMap<String, String> = mutableMapOf()
) {
    companion object {
        fun createItem(eventKey: String): EventItem {
            return EventItem(
                eventKey,
                RewardSDKApiInfoModule.getAppCode(),
                System.currentTimeMillis()
            )
        }
    }

    fun addExtra(key: String, value: String) {
        extra[key] = value
    }

    fun getExtra(): Map<String, String> = extra
}
