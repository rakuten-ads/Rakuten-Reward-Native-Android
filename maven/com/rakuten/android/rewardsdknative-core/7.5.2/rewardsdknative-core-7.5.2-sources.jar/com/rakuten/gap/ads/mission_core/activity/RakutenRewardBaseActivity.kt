package com.rakuten.gap.ads.mission_core.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.rakuten.gap.ads.mission_core.RakutenReward
import com.rakuten.gap.ads.mission_core.RakutenRewardLifecycle
import com.rakuten.gap.ads.mission_core.api.status.RakutenRewardClaimStatus
import com.rakuten.gap.ads.mission_core.data.MissionAchievementData
import com.rakuten.gap.ads.mission_core.data.RakutenRewardUser
import com.rakuten.gap.ads.mission_core.internal.ExcludeJacocoGeneratedReport
import com.rakuten.gap.ads.mission_core.listeners.RakutenRewardListener
import com.rakuten.gap.ads.mission_core.observers.RakutenRewardManager
import com.rakuten.gap.ads.mission_core.status.RakutenRewardSDKStatus

/**
 * This is the Base Activity class to start Reward SDK. It will sync up user data by default. <br/><br/>
 * If Activity class extension is not an option, there are 2 other options to start Reward SDK. Refer to see also.
 *
 * @see [RakutenRewardLifecycle]
 * @see [RakutenRewardManager.bindRakutenRewardIn]
 */
@ExcludeJacocoGeneratedReport
open class RakutenRewardBaseActivity : AppCompatActivity(), RakutenRewardListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        RakutenReward.addRakutenRewardListener(this)
        RakutenRewardLifecycle.onCreate(this, lifecycleScope)
    }

    override fun onStart() {
        RakutenReward.addRakutenRewardListener(this)
        super.onStart()
        RakutenRewardLifecycle.onStart(this, lifecycleScope)
    }

    override fun onDestroy() {
        super.onDestroy()
        RakutenRewardLifecycle.onDestroy()
    }

    override fun onResume() {
        RakutenReward.addRakutenRewardListener(this)
        super.onResume()
        RakutenRewardLifecycle.onResume(this)
    }

    override fun onPause() {
        super.onPause()
        RakutenReward.removeRakutenRewardListener(this)
    }

    /* RakutenRewardListener */
    /**
     * Triggered when user achieved a mission
     */
    override fun onUnclaimedAchievement(achievement: MissionAchievementData) = Unit

    /**
     * Triggered when user data is updated
     */
    override fun onUserUpdated(user: RakutenRewardUser) = Unit

    /**
     * Triggered when Reward SDK status is changed
     */
    override fun onSDKStatusChanged(status: RakutenRewardSDKStatus) = Unit

    /**
     * Triggered when Claim View is closed
     */
    override fun onSDKClaimClosed(
        missionAchievementData: MissionAchievementData,
        status: RakutenRewardClaimStatus
    ) = Unit

    /**
     * Triggered when Consent View is closed
     */
    override fun onSDKConsentClosed() = Unit

    /**
     * Triggered when Consent View is presented
     */
    override fun onSDKConsentPresented() = Unit

    /**
     * Triggered when Claim View is presented
     */
    override fun onSDKClaimPresented(missionAchievementData: MissionAchievementData) = Unit
}
