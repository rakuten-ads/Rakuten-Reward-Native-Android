package com.rakuten.gap.ads.mission_core

import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.pm.ProviderInfo
import android.database.Cursor
import android.net.Uri
import android.util.Log
import com.google.android.gms.ads.identifier.AdvertisingIdClient
import com.rakuten.gap.ads.common.logger.RewardDebugLog
import com.rakuten.gap.ads.mission_core.database.helpers.RakutenRewardDatabaseHelper
import com.rakuten.gap.ads.mission_core.di.AppContainer
import com.rakuten.gap.ads.mission_core.di.ContainerProvider
import com.rakuten.gap.ads.mission_core.di.provider.CoroutineProvider
import com.rakuten.gap.ads.mission_core.di.provider.DbHelperProvider
import com.rakuten.gap.ads.mission_core.di.provider.UseCaseProvider
import com.rakuten.gap.ads.mission_core.helpers.TokenHelper
import com.rakuten.gap.ads.mission_core.helpers.UIHelper
import com.rakuten.gap.ads.mission_core.internal.ExcludeJacocoGeneratedReport
import com.rakuten.gap.ads.mission_core.modules.ModuleProvider
import com.rakuten.gap.ads.mission_core.modules.singleton.RewardSDKApiInfoModule
import com.rakuten.gap.ads.mission_core.resource.RewardStringResource
import com.rakuten.gap.ads.mission_core.settings.RakutenRewardSDKInternalSettings
import com.rakuten.gap.ads.mission_core.settings.RakutenRewardSDKSettings
import com.rakuten.gap.ads.mission_remote.RewardRemote
import java.util.Calendar
import kotlin.concurrent.thread

/**
 * @suppress
 *
 * This class handle Reward SDK initialization
 */
@ExcludeJacocoGeneratedReport
class RakutenRewardContentProvider : ContentProvider() {
    @ExcludeJacocoGeneratedReport
    companion object {
        private const val TAG = "ContentProvider"
        private const val SDK_TAG = "RakutenRewardSDK"
        private const val APPCODE_METADATA = "com.rakuten.gap.ads.mission_core.appKey"
    }

    override fun onCreate(): Boolean {
        val startTime = Calendar.getInstance().timeInMillis
        RewardDebugLog.init(isDebugMode())
        val appContext = context
        if (appContext != null) {
            initiateDI(appContext)
            retrieveAppCode(appContext)
            retrieveInfo(appContext)
        } else {
            Log.w(SDK_TAG, "Failed to initiate Reward SDK due to null Context.")
        }
        val endTime = Calendar.getInstance().timeInMillis
        val diff = endTime - startTime
        RewardDebugLog.d(TAG, "ContentProvider used time: $diff ms")
        return true
    }

    private fun isDebugMode(): Boolean = (BuildConfig.DEBUG || BuildConfig.FLAVOR == "qa")

    private fun initiateDI(appContext: Context) {
        val dbHelper = RakutenRewardDatabaseHelper(appContext).apply {
            this.writableDatabase
            close()
        }
        val appContainer = AppContainer.Builder(appContext)
            .addProvider(CoroutineProvider())
            .addProvider(ModuleProvider())
            .addProvider(UseCaseProvider())
            .addProvider(DbHelperProvider(dbHelper))
            .build()

        ContainerProvider.setAppContainer(appContainer)
        RakutenRewardSDKSettings.setPreferenceHelper(appContainer.getPreferenceHelper())
        RakutenRewardSDKInternalSettings.setPreferenceHelper(appContainer.getPreferenceHelper())
        TokenHelper.setPreferenceHelper(appContainer.getPreferenceHelper())

        // Init Reward Remote
        RewardRemote.init(appContext)
        RewardStringResource.init()
    }

    private fun retrieveInfo(appContext: Context) {
        getDeviceInfo(appContext)
        getAppInfo(appContext)
        getAdId(appContext)
    }

    private fun getAppInfo(appContext: Context) {
        // App Name
        RewardSDKApiInfoModule.setAppName(appContext.packageName)
    }

    private fun getDeviceInfo(appContext: Context) {
        RewardSDKApiInfoModule.setDeviceType(UIHelper.isTablet(appContext))
    }

    private fun getAdId(appContext: Context) {
        thread {
            try {
                Class.forName("com.google.android.gms.ads.identifier.AdvertisingIdClient")
                val adInfo = AdvertisingIdClient.getAdvertisingIdInfo(appContext)
                val adId = adInfo.id
                if (!adInfo.isLimitAdTrackingEnabled && adId != null) {
                    RewardSDKApiInfoModule.setAdid(adId)
                    RewardDebugLog.d(TAG, "Ad ID: $adId")
                }

            } catch (e: Exception) {
                Log.w(SDK_TAG, "Advertisement ID is not available")
                RewardDebugLog.w(TAG, "AD ID not available", e)
            }
        }
    }

    private fun retrieveAppCode(appContext: Context) {
        val appCode = try {
            val ai: ApplicationInfo = appContext.packageManager.getApplicationInfo(
                appContext.packageName,
                PackageManager.GET_META_DATA
            )
            val bundle = ai.metaData
            bundle.getString(APPCODE_METADATA)
        } catch (e: Exception) {
            RewardDebugLog.e(TAG, "Retrieved Metadata failed", e)
            null
        }

        if (appCode.isNullOrEmpty()) {
            Log.e(
                SDK_TAG,
                "Since v3.3.0, manual Reward SDK initialization is no longer needed. Don't forget to configure <meta-data android:name=\"$APPCODE_METADATA\" android:value=\"appKey\"/> in your AndroidManifest.xml file."
            )
        } else {
            RewardDebugLog.d(TAG, "Retrieved AppCode: $appCode")
            RakutenReward.init(appCode)
        }
    }

    override fun attachInfo(context: Context?, info: ProviderInfo?) {
        // to ensure NO two client application have the same authority name
        if (info == null) {
            throw IllegalStateException(
                "RakutenRewardContentProvider | attachInfo() | This component cannot work with null providerInfo."
            )
        }

        val simpleName = try {
            "com.rakuten.gap.ads.mission_core.${RakutenRewardContentProvider::class.java.simpleName}"
        } catch (e: Exception) {
            RewardDebugLog.w(TAG, "Access class name error", e)
            null
        }

        if (simpleName == null || simpleName == info.authority) {
            throw IllegalStateException(
                "RakutenRewardContentProvider | attachInfo() | Incorrect provider authority. " +
                        "Most likely due to a missing applicationId variable in application's build.gradle."
            )
        }

        super.attachInfo(context, info)
    }

    @ExcludeJacocoGeneratedReport
    override fun query(
        p0: Uri,
        p1: Array<out String>?,
        p2: String?,
        p3: Array<out String>?,
        p4: String?
    ): Cursor? = null

    @ExcludeJacocoGeneratedReport
    override fun getType(p0: Uri): String? = null

    @ExcludeJacocoGeneratedReport
    override fun insert(p0: Uri, p1: ContentValues?): Uri? = null

    @ExcludeJacocoGeneratedReport
    override fun delete(p0: Uri, p1: String?, p2: Array<out String>?): Int = 0

    @ExcludeJacocoGeneratedReport
    override fun update(p0: Uri, p1: ContentValues?, p2: String?, p3: Array<out String>?): Int = 0
}