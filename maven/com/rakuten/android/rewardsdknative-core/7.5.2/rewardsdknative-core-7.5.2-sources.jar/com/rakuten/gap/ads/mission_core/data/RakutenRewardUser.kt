package com.rakuten.gap.ads.mission_core.data

/**
 * This is Rakuten Reward User Basic Data (For callback, initialization)
 */
data class RakutenRewardUser(
    /**
     * Number of unclaimed items
     */
    var unclaimed: Int = 0,
    /**
     * Is user signed in
     */
    var signin: Boolean = false,
    /**
     * Point which user got from Reward Service
     */
    var point: Int = 0,
    /**
     * Mission list. <mark>Not in used anymore</mark>
     */
    var achievementList: List<MissionAchievementData> = listOf()
) {
    /**
     * @suppress
     */
    override fun equals(other: Any?): Boolean {
        if (other == null) {
            return false
        }
        if (other !is RakutenRewardUser) return false
        return (this.unclaimed == other.unclaimed && this.signin == other.signin && this.point == other.point)
    }

    /**
     * @suppress
     */
    override fun hashCode(): Int {
        var result = unclaimed
        result = 31 * result + signin.hashCode()
        result = 31 * result + point
        return result
    }

    /**
     * @suppress
     */
    companion object {
        fun createBlankUser(): RakutenRewardUser {
            val user = RakutenRewardUser()
            user.signin = false
            user.point = 0
            user.unclaimed = 0
            return user
        }
    }
}