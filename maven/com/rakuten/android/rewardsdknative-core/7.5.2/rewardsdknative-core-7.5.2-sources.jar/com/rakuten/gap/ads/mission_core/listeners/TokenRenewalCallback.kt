package com.rakuten.gap.ads.mission_core.listeners

internal interface TokenRenewalCallback {
    fun onTokenRenewalSucceed()
    fun onTokenRenewalFailed()
}