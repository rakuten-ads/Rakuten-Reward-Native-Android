package com.rakuten.gap.ads.mission_core.listeners.java

import com.rakuten.gap.ads.mission_core.api.status.RakutenRewardAPIError
import com.rakuten.gap.ads.mission_core.data.MissionData

/**
 * Get mission details callback
 */
interface GetMissionDetailsCallback {
    /**
     * Success callback
     *
     * @param [missions] MissionData object
     */
    fun success(missions: MissionData)

    /**
     * Failure callback
     */
    fun fail(e: RakutenRewardAPIError)
}