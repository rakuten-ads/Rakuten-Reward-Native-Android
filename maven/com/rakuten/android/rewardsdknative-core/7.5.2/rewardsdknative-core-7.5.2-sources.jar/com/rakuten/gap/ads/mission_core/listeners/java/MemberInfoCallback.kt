package com.rakuten.gap.ads.mission_core.listeners.java

import com.rakuten.gap.ads.mission_core.api.status.RakutenRewardAPIError
import com.rakuten.gap.ads.mission_core.data.RakutenRewardUser

/**
 * Get member's info callback
 */
interface MemberInfoCallback {
    /**
     * Success callback
     *
     * @param [sdkuser] User info data
     */
    fun success(sdkuser: RakutenRewardUser)

    /**
     * Failure callback
     */
    fun fail(e: RakutenRewardAPIError)
}