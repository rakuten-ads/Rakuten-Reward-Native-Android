package com.rakuten.gap.ads.mission_core.data

/**
 * User info class for Rakuten Auth users
 */
data class RakutenAuthUserInfo(
    /**
     * Total Rakuten point for the user
     */
    val points: Long,
    /**
     * User's Rakuten account rank
     * <table>
     *     <tr>
     *         <th>Rank</th>
     *         <th>Description</th>
     *     </tr>
     *     <tr>
     *         <td>1</td>
     *         <td>Regular</td>
     *     </tr>
     *     <tr>
     *         <td>2</td>
     *         <td>Silver</td>
     *     </tr>
     *     <tr>
     *         <td>3</td>
     *         <td>Gold</td>
     *     </tr>
     *     <tr>
     *         <td>4</td>
     *         <td>Platinum</td>
     *     </tr>
     *     <tr>
     *         <td>5</td>
     *         <td>Diamond</td>
     *     </tr>
     * </table>
     */
    val rank: Int
)