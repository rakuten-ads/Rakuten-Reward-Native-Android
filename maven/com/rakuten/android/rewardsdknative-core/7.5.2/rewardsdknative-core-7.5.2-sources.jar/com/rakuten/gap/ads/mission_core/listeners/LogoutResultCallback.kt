package com.rakuten.gap.ads.mission_core.listeners

import com.rakuten.gap.ads.mission_core.api.status.RakutenRewardAPIError

/**
 * Log Out result callback
 */
interface LogoutResultCallback {
    /**
     * Logged out successfully
     */
    fun logoutSuccess()

    /**
     * Log out failed
     */
    fun logoutFailed(e: RakutenRewardAPIError)
}