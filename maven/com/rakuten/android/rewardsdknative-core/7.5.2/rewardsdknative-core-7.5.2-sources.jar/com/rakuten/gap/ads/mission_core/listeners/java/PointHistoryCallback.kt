package com.rakuten.gap.ads.mission_core.listeners.java

import com.rakuten.gap.ads.mission_core.api.status.RakutenRewardAPIError
import com.rakuten.gap.ads.mission_core.data.RakutenRewardPointHistory

/**
 * Get user's last 3 months point history callback
 */
interface PointHistoryCallback {
    /**
     * Success callback
     *
     * @param [pointHistory] RakutenRewardPointHistory instance which contain last 3 months point history data
     */
    fun success(pointHistory: RakutenRewardPointHistory)

    /**
     * Failure callback
     */
    fun fail(e: RakutenRewardAPIError)
}