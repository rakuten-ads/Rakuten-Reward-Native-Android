package com.rakuten.gap.ads.mission_core.listeners.java

import com.rakuten.gap.ads.mission_core.api.status.RakutenRewardAPIError
import com.rakuten.gap.ads.mission_core.data.MissionAchievementData

/**
 * Get the list of unclaimed items callback
 */
interface UnclaimedItemCallback {
    /**
     * Success callback
     *
     * @param [missions] list of unclaimed items
     */
    fun success(missions: List<MissionAchievementData>)

    /**
     * Failure callback
     */
    fun failed(e: RakutenRewardAPIError)
}