package com.rakuten.gap.ads.mission_ui.api.activity

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.OnBackPressedCallback
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayout.Tab
import com.rakuten.gap.ads.mission_core.RakutenReward
import com.rakuten.gap.ads.mission_core.helpers.CookieHelper
import com.rakuten.gap.ads.mission_core.helpers.getString
import com.rakuten.gap.ads.mission_core.internal.EventNames
import com.rakuten.gap.ads.mission_ui.databinding.RakutenrewardUiPortalActivityBinding
import com.rakuten.gap.ads.mission_ui.ui.fragment.tab.AbstractRewardTabFragment
import com.rakuten.gap.ads.mission_ui.ui.fragment.tab.PortalTab
import com.rakuten.gap.ads.mission_ui.ui.pageadapter.TabPageAdapter
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Rakuten Reward SDK Portal screen
 */
class RakutenRewardSDKPortalActivity : AbstractPortalActivity() {
    companion object {
        private const val TOKEN_EXPIRE_CODE = 100
    }

    private lateinit var binding: RakutenrewardUiPortalActivityBinding

    private lateinit var adapter: TabPageAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = RakutenrewardUiPortalActivityBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, 0, systemBars.right, systemBars.bottom)
            insets
        }

        binding.rakutenrewardToobar.rakutenrewardPortalclose.setOnClickListener {
            closePortal()
        }

        // Cookie Updates
        CookieHelper.jpCookieSupport()

        adapter = TabPageAdapter(supportFragmentManager)
        binding.headerTitle = remoteResources.getString(PortalTab.HOME.titleKey)

        PortalTab.values().forEach {
            binding.tabLayout.addTab(
                binding.tabLayout.newTab()
                    .setText(remoteResources.getString(it.titleKey))
                    .setIcon(it.getDefaultIcon())
            )

            adapter.addFragment(it.getFragment(), remoteResources.getString(it.titleKey))
        }

        binding.pager.offscreenPageLimit = PortalTab.values().size
        binding.pager.adapter = adapter
        binding.pager.addOnPageChangeListener(TabLayout.TabLayoutOnPageChangeListener(binding.tabLayout))
        binding.tabLayout.addOnTabSelectedListener(object :
            TabLayout.ViewPagerOnTabSelectedListener(binding.pager) {
            override fun onTabSelected(tab: Tab) {
                super.onTabSelected(tab)
                val text = tab.text
                if (!text.isNullOrEmpty()) {
                    binding.rakutenrewardToobar.rakutenrewardportalHeaderTitle.text = text
                }
                PortalTab.getTab(tab.position)?.let { portalTab ->
                    tab.setIcon(portalTab.selectedIcon)
                }

                // don't load page when screen orientation changed
                if (savedInstanceState == null || savedInstanceState.isEmpty) {
                    val fragment = adapter.getRealItem(tab.position)
                    if (fragment is AbstractRewardTabFragment) {
                        fragment.loadPage()
                    }
                }
            }

            override fun onTabUnselected(tab: Tab?) {
                super.onTabUnselected(tab)
                tab?.let {
                    PortalTab.getTab(it.position)?.let { portalTab ->
                        it.setIcon(portalTab.normalIcon)
                    }
                    cacheOpenPageEvent(it)
                }
            }
        })
        binding.lifecycleOwner = this
        viewModel.updateMemberOnlyInfo(RakutenReward.user.point, RakutenReward.user.unclaimed)

        viewModel.fullscreenLoadIndicator.observe(this) { show ->
            binding.fullscreenLoading.visibility = if (show) View.VISIBLE else View.GONE
        }

        // RWDSDK-10666 | Android 16 no longer trigger onBackPressed() when the back button is pressed
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                closePortal()
            }
        })
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (binding.pager.currentItem != PortalTab.HOME.index) {
            moveTab(PortalTab.HOME)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        CookieHelper.syncCookie()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == TOKEN_EXPIRE_CODE) {
            finish()
        }
    }

    private fun closePortal() {
        cacheCloseEvent()
        finish()
    }

    private fun cacheOpenPageEvent(tab: Tab) {
        lifecycleScope.launch {
            delay(200)
            val eventName = eventTrackingViewModel.getOpenPageEventName(binding.pager.currentItem)
            val from = eventTrackingViewModel.getTabFromValue(tab.position)
            eventTrackingViewModel.cacheEvent(eventName, mapOf(EventNames.EXTRA_FROM to from))
        }
    }

    private fun cacheCloseEvent() {
        val fromValue = eventTrackingViewModel.getTabFromValue(binding.pager.currentItem)
        eventTrackingViewModel.cacheEvent(
            EventNames.CLOSE_SDK_PORTAL, mapOf(EventNames.EXTRA_FROM to fromValue)
        )
    }

    override fun <Y : PortalTab> moveTab(portalTab: Y) {
        binding.pager.currentItem = portalTab.index
    }

    override fun getCurrentTab(): PortalTab {
        return PortalTab.getTab(binding.pager.currentItem) ?: PortalTab.HOME
    }
}