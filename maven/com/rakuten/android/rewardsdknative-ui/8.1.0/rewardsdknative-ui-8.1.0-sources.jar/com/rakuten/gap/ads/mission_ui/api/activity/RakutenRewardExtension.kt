package com.rakuten.gap.ads.mission_ui.api.activity

import android.app.Activity
import android.view.View.OnClickListener
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultCallback
import com.rakuten.gap.ads.mission_core.RakutenReward
import com.rakuten.gap.ads.mission_core.RakutenRewardConfig
import com.rakuten.gap.ads.mission_core.RewardApiResult
import com.rakuten.gap.ads.mission_core.modules.singleton.RewardSDKActivityModule
import com.rakuten.gap.ads.mission_core.settings.RakutenRewardSDKInternalSettings

/**
 *
 * Open SDK Portal UI
 *
 * @receiver [RakutenReward]
 * @param [requestCode] Request Code to handle SDK portal closed event in [Activity.onActivityResult]
 * @return true - launch SDK portal successfully<br/>false - failed to launch SDK portal
 *
 *
 * <b>Sample to handle closed event</b>
 *
 * ```kotlin
 * RakutenReward.openSDKPortal(100)
 *
 * override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
 *      if (requestCode == 100) {
 *          // handle closed event
 *     }
 * }
 * ```
 *
 * <b>Since v4.0.0, User Consent feature is integrated into SDK. </b>
 *
 * If user have not provide consent yet, [RakutenReward.requestForConsent] API will be called to request for user's consent.
 * Once user provided consent will proceed to open SDK Portal
 *
 */
@Deprecated(
    message = "This API return a boolean value to indicate whether SDK portal is launched or not. However this is deprecated now as the returned value may not be correct.",
    replaceWith = ReplaceWith("RakutenReward.openSDKPortal({}, requestCode)")
)
@JvmName("openSDKPortal")
@JvmOverloads
fun RakutenReward.openSDKPortal(requestCode: Int = 515): Boolean {
    return RewardSDKActivityModule.openRewardActivity(
        cls = RakutenRewardSDKPortalActivity::class.java,
        requestCode = requestCode
    )
}

/**
 *
 * Open SDK Portal UI
 *
 * @receiver [RakutenReward]
 * @param [activityResultCallback] ActivityResultCallback to be triggered when SDK portal is closed.
 * @return true - launch SDK portal successfully<br/>false - failed to launch SDK portal
 *
 *
 * <b>Sample to handle closed event</b>
 *
 * ```kotlin
 * RakutenReward.openSDKPortal {
 *      // handle closed event
 * }
 * ```
 *
 * @since v3.4.2
 *
 * <b>Since v4.0.0, User Consent feature is integrated into SDK.</b>
 *
 * If user have not provide consent yet, [RakutenReward.requestForConsent] API will be called to request for user's consent.
 * Once user provided consent will proceed to open SDK Portal
 *
 */
@Deprecated(
    message = "This API return a boolean value to indicate whether SDK portal is launched or not. However this is deprecated now as the returned value may not be correct.",
    replaceWith = ReplaceWith("RakutenReward.openSDKPortal(isPortalOpenedCallback = {}, activityResultCallback = activityResultCallback)")
)
fun RakutenReward.openSDKPortal(activityResultCallback: ActivityResultCallback<ActivityResult>): Boolean {
    return RewardSDKActivityModule.openRewardActivity(
        cls = RakutenRewardSDKPortalActivity::class.java,
        requestCode = 515,
        activityResultCallback = activityResultCallback
    )
}

/**
 *  Open SDK Portal UI
 *
 * @receiver [RakutenReward]
 * @param [isPortalOpenedCallback] Callback to get the result of whether SDK portal is opened or not.
 * @param [requestCode] Request Code to handle SDK portal closed event in [Activity.onActivityResult]
 * @param [activityResultCallback] ActivityResultCallback to be triggered when SDK portal is closed.
 *
 * Use either [requestCode] or [activityResultCallback] to handle SDK portal closed event.
 *
 *
 * <b>Sample to get Portal launched result</b>
 *
 * ```kotlin
 * RakutenReward.openSDKPortal({ result ->
 *      when (result) {
 *          is Failed -> // Failed to open Portal. Get the error here `result.error`
 *          is Success -> // SDK Portal opened successfully
 *      }
 * }) {
 *     // handle closed event
 * }
 * ```
 *
 *  @since v6.0.0
 */
@JvmOverloads
fun RakutenReward.openSDKPortal(
    isPortalOpenedCallback: (RewardApiResult<Unit>) -> Unit,
    requestCode: Int = 515,
    activityResultCallback: ActivityResultCallback<ActivityResult>? = null
) {
    RewardSDKActivityModule.openRewardActivity(
        cls = RakutenRewardSDKPortalActivity::class.java,
        requestCode = requestCode,
        isPortalOpenedCallback = isPortalOpenedCallback,
        activityResultCallback = activityResultCallback
    )
}

internal fun RakutenReward.openSDKPortalWithoutResult() {
    RewardSDKActivityModule.openRewardActivity(RakutenRewardSDKPortalActivity::class.java)
}

/**
 *
 * Configuration to set whether using SDK Portal UI. By default is true.
 *
 * @receiver [RakutenRewardConfig]
 * @param [isUsing] true - is using SDK Portal, false - not using SDK Portal
 *
 * @since v3.5.0
 *
 */
fun RakutenRewardConfig.isUsingSdkPortal(isUsing: Boolean) {
    if (isUsing) {
        RakutenRewardSDKInternalSettings.setHomeLinkOnClickListener(onClickListener)
    } else {
        RakutenRewardSDKInternalSettings.setHomeLinkOnClickListener(null)
    }
}

private val onClickListener: OnClickListener by lazy {
    OnClickListener {
        RakutenReward.forceClaimClose()
        RakutenReward.openSDKPortalWithoutResult()
    }
}