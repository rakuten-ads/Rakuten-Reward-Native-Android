package com.rakuten.gap.ads.mission_ui.api.activity

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.rakuten.gap.ads.mission_core.RakutenReward
import com.rakuten.gap.ads.mission_core.RakutenRewardLifecycle
import com.rakuten.gap.ads.mission_core.api.status.RakutenRewardClaimStatus
import com.rakuten.gap.ads.mission_core.data.MissionAchievementData
import com.rakuten.gap.ads.mission_core.data.RakutenRewardUser
import com.rakuten.gap.ads.mission_core.helpers.RemoteResources
import com.rakuten.gap.ads.mission_core.helpers.getRemoteResources
import com.rakuten.gap.ads.mission_core.listeners.RakutenRewardListener
import com.rakuten.gap.ads.mission_core.modules.singleton.RewardSDKActivityModule
import com.rakuten.gap.ads.mission_core.status.RakutenRewardSDKStatus
import com.rakuten.gap.ads.mission_core.ui.dialog.RakutenRewardSimpleConfirmationDialogListener
import com.rakuten.gap.ads.mission_ui.observer.EventTrackingObserver
import com.rakuten.gap.ads.mission_ui.ui.fragment.tab.PortalTab
import com.rakuten.gap.ads.mission_ui.viewmodel.EventTrackingViewModel
import com.rakuten.gap.ads.mission_ui.viewmodel.RewardSDKPortalViewModel

/**
 *
 * @author zack.keng
 * Created on 2024/03/20
 * Copyright © 2024 Rakuten Asia. All rights reserved.
 */
abstract class AbstractPortalActivity : AppCompatActivity(),
    RakutenRewardSimpleConfirmationDialogListener, RakutenRewardListener {

    abstract fun <Y : PortalTab> moveTab(portalTab: Y)
    abstract fun getCurrentTab(): PortalTab

    val viewModel: RewardSDKPortalViewModel by viewModels()

    val eventTrackingViewModel: EventTrackingViewModel by viewModels()

    val remoteResources: RemoteResources by lazy {
        getRemoteResources()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        RakutenReward.addRakutenRewardListener(this)
        RakutenRewardLifecycle.onCreate(this)
        viewModel.setRemoteResources(remoteResources)
        EventTrackingObserver.bindActivity(this, eventTrackingViewModel)
    }

    override fun onStart() {
        RakutenReward.addRakutenRewardListener(this)
        super.onStart()
        RakutenRewardLifecycle.onStart(this)
    }

    override fun onResume() {
        RakutenReward.addRakutenRewardListener(this)
        super.onResume()
        RakutenRewardLifecycle.onResume(this)
    }

    override fun onPause() {
        super.onPause()
        RakutenReward.removeRakutenRewardListener(this)
    }

    override fun onUnclaimedAchievement(achievement: MissionAchievementData) = Unit

    override fun onUserUpdated(user: RakutenRewardUser) {
        viewModel.updateMemberOnlyInfo(user.point, user.unclaimed)
        viewModel.updateUnclaimlist()
    }

    override fun onSDKStatusChanged(status: RakutenRewardSDKStatus) {
        when (status) {
            RakutenRewardSDKStatus.ONLINE -> {
                viewModel.updateMemberOnlyInfo(
                    RakutenReward.user.point, RakutenReward.user.unclaimed
                )
                viewModel.getRakutenAuthUserInfo()
            }

            RakutenRewardSDKStatus.TOKENEXPIRED -> {
                RewardSDKActivityModule.openTokenExpireDialog(this)
            }

            else -> viewModel.unclaimError() // update Unclaim tab as error
        }
    }

    override fun onSDKClaimClosed(
        missionAchievementData: MissionAchievementData,
        status: RakutenRewardClaimStatus
    ) {
        viewModel.claimUiClosed(status)
    }

    override fun onSDKConsentClosed() = Unit

    override fun onSDKConsentPresented() = Unit

    override fun onSDKClaimPresented(missionAchievementData: MissionAchievementData) = Unit

    override fun closeRakutenRewardConfirmationDialog() {
        finish()
    }
}