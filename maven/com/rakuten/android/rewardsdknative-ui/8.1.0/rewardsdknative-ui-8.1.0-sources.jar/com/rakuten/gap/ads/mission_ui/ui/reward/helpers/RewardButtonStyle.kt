package com.rakuten.gap.ads.mission_ui.ui.reward.helpers

/**
 * Enumeration class of Reward SDK Button Style
 */
enum class RewardButtonStyle {
    DARK, LIGHT
}