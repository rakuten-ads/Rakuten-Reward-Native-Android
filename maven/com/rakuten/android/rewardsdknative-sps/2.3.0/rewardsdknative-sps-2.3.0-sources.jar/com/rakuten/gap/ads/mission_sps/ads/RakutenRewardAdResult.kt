package com.rakuten.gap.ads.mission_sps.ads

/**
 * Result of an interstitial ad display attempt via [RakutenMissionSpsAds.showInterstitialAd].
 *
 * Created on 2026/05/13
 * Copyright © 2026 Rakuten Asia. All rights reserved.
 */
sealed class RakutenRewardAdResult {

    /**
     * The interstitial ad was displayed successfully.
     */
    object AdShown : RakutenRewardAdResult()

    /**
     * No ad was shown. This can occur when:
     * - No [InterstitialAdProvider] is registered.
     * - [jp.co.rakuten.sps.web.model.InterstitialAdConfig.adUnitId] is null or empty.
     * - The ad failed to load within the timeout period.
     * - The ad failed to display after loading.
     */
    object NoAdShown : RakutenRewardAdResult()
}
