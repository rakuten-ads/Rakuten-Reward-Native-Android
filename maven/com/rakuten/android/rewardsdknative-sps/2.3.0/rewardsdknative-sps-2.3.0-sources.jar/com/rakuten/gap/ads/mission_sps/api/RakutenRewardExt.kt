package com.rakuten.gap.ads.mission_sps.api

import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultCallback
import com.rakuten.gap.ads.mission_core.RakutenReward
import com.rakuten.gap.ads.mission_core.RakutenRewardConfig
import com.rakuten.gap.ads.mission_core.RewardApiResult
import com.rakuten.gap.ads.mission_sps.activity.mode.MissionTheme
import com.rakuten.gap.ads.mission_sps.internal.InternalMissionSps
import com.rakuten.gap.ads.mission_sps.internal.SpsInternalSettings
import com.rakuten.gap.ads.mission_sps.listener.SpsMissionListener

/**
 * Open SPS Portal UI
 *
 * @receiver [RakutenReward]
 * @param [rz] Rz Cookie value. @since 7.3.0, Rz Cookie is mandatory for personalized experience in SPS Home Screen
 * @param [isPortalOpenedCallback] Callback to get the result of whether SPS portal is opened or not.
 * @param [activityResultCallback] ActivityResultCallback to be triggered when SPS portal is closed.
 *
 *
 * <b>Sample to handle closed event</b>
 *
 * ```kotlin
 * RakutenReward.openSpsPortal({ result ->
 *    when (result) {
 *       is Failed -> // Failed to open Portal. Get the error here `result.error`
 *       is Success -> // SDK Portal opened successfully
 *   }
 * }) {
 *     // handle portal closed event
 * }
 * ```
 */
@JvmName("openSpsPortal")
@JvmOverloads
fun RakutenReward.openSpsPortal(
    rz: String,
    isPortalOpenedCallback: ((RewardApiResult<Unit>) -> Unit)? = null,
    activityResultCallback: ActivityResultCallback<ActivityResult>? = null
) {
    setRz(rz)
    InternalMissionSps.openSpsPortal(null, isPortalOpenedCallback, activityResultCallback)
}

/**
 * Open SPS Portal UI
 *
 * @receiver [RakutenReward]
 * @param [rz] Rz Cookie value. @since 7.3.0, Rz Cookie is mandatory for personalized experience in SPS Home Screen
 * @param [deeplink] Deeplink to open specific page in SPS Portal.
 * @param [isPortalOpenedCallback] Callback to get the result of whether SPS portal is opened or not.
 * @param [activityResultCallback] ActivityResultCallback to be triggered when SPS portal is closed.
 *
 * @since 8.3.0
 */
fun RakutenReward.openSpsPortal(
    rz: String,
    deeplink: String,
    isPortalOpenedCallback: ((RewardApiResult<Unit>) -> Unit)? = null,
    activityResultCallback: ActivityResultCallback<ActivityResult>? = null
) {
    setRz(rz)
    InternalMissionSps.openSpsPortal(deeplink, isPortalOpenedCallback, activityResultCallback)
}

/**
 * Set theme for point mission
 *
 * @receiver [RakutenRewardConfig]
 * @see [MissionTheme]
 * @see [SpsMissionListener.onThemeChanged]
 *
 * In SPS Portal, user can change the theme in more settings page.
 * To listen the theme changed event, you can implement [SpsMissionListener.onThemeChanged] and set it by [RakutenMissionSps.setSpsMissionListener]
 *
 * <b>Sample to listen theme changed event</b>
 *
 * ```kotlin
 * RakutenMissionSps.setSpsMissionListener(object : SpsMissionListener {
 *      fun onThemeChanged(theme: MissionTheme) {
 *          // handle theme changed event
 *      }
 * })
 * ```
 */
@JvmName("setTheme")
fun RakutenRewardConfig.setTheme(theme: MissionTheme) {
    SpsInternalSettings.setSpsTheme(theme.getThemeId())
}

/**
 * Get current theme for point mission
 *
 * @receiver [RakutenRewardConfig]
 * @see [MissionTheme]
 * @see [SpsMissionListener.onThemeChanged]
 */
@JvmName("getTheme")
fun RakutenRewardConfig.getTheme(): MissionTheme {
    return MissionTheme.getThemeById(SpsInternalSettings.getSpsTheme())
}

/**
 * Opt out mission features
 *
 * @receiver [RakutenRewardConfig]
 * @param [isOptOut] true to opt out mission features, false to opt in.
 *
 * @since 7.0.0
 */
@JvmName("setOptOutMissionFeatures")
fun RakutenRewardConfig.setOptOutMissionFeatures(isOptOut: Boolean) {
    SpsInternalSettings.setOptOutMission(isOptOut)
}

/**
 * Check if mission features are opted out
 *
 * @receiver [RakutenRewardConfig]
 * @return true if mission features are opted out, false otherwise.
 *
 * @since 7.0.0
 */
@JvmName("isMissionFeaturesOptedOut")
fun RakutenRewardConfig.isMissionFeaturesOptedOut(): Boolean {
    return SpsInternalSettings.getOptOutMission()
}
