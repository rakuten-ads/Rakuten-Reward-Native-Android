package com.rakuten.gap.ads.mission_sps.ads

import android.app.Activity
import android.content.Context
import jp.co.rakuten.sps.web.model.InterstitialAdConfig

/**
 * Contract for an interstitial ad implementation.
 *
 * Implement this interface to provide a custom interstitial ad solution and register it
 * via [RakutenMissionSpsAds.registerInterstitialAdProvider].
 *
 * The default implementation backed by the Google Mobile Ads SDK is provided automatically
 * by the `mission-ads` module.
 *
 * Created on 2026/05/13
 * Copyright © 2026 Rakuten Asia. All rights reserved.
 */
interface InterstitialAdProvider {

    /**
     * Pre-loads and caches an interstitial ad for later display.
     *
     * Implementations should skip loading if a valid cached ad is still within
     * [InterstitialAdConfig.adCacheTimeMillis] and do nothing if
     * [InterstitialAdConfig.adUnitId] is null or empty.
     *
     * @param context Application or Activity context.
     * @param adConfig Ad configuration containing the ad unit ID and cache settings.
     */
    fun preLoad(context: Context, adConfig: InterstitialAdConfig)

    /**
     * Shows an interstitial ad, loading one on-demand if no valid cached ad is available.
     *
     * Implementations must invoke [adResult] exactly once on the main thread with either
     * [RakutenRewardAdResult.AdShown] or [RakutenRewardAdResult.NoAdShown].
     *
     * @param activity The foreground [Activity] used to display the ad.
     * @param adConfig Ad configuration containing the ad unit ID, cache settings, and load timeout.
     * @param adResult Callback invoked with the result once the ad sequence completes.
     */
    fun showAd(activity: Activity, adConfig: InterstitialAdConfig, adResult: (RakutenRewardAdResult) -> Unit)
}
