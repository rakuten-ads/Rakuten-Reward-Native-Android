@file:Suppress("unused")

package com.rakuten.gap.ads.mission_sps.api

import android.content.Context
import android.graphics.Color
import android.os.Handler
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.animation.BounceInterpolator
import android.view.animation.TranslateAnimation
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.annotation.DrawableRes
import com.rakuten.gap.ads.mission_core.RakutenReward
import com.rakuten.gap.ads.mission_core.data.EventItem
import com.rakuten.gap.ads.mission_core.internal.EventNames
import com.rakuten.gap.ads.mission_core.internal.SdkModuleApi
import com.rakuten.gap.ads.mission_core.status.RakutenRewardSDKStatus
import com.rakuten.gap.ads.mission_core.ui.reward.IRewardButton
import com.rakuten.gap.ads.mission_core.ui.reward.RewardButtonManager
import com.rakuten.gap.ads.mission_sps.internal.InternalMissionSps
import com.rakuten.gap.ads.mission_ui.R
import com.rakuten.gap.ads.mission_ui.databinding.RakutenrewardUiRewardButtonBinding
import com.rakuten.gap.ads.mission_ui.ui.reward.helpers.BadgePosition
import com.rakuten.gap.ads.mission_ui.ui.reward.helpers.RewardButtonStyle
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.min

/**
 * Rakuten Reward SDK Official button to access SPS SDK Home.<br></br>
 * This button manage Reward SDK session status(Disable and gray out indicates session is OFFLINE or disable feature).
 */
class SpsButton(context: Context, attrs: AttributeSet?) :
    FrameLayout(context, attrs), IRewardButton {

    private var binding: RakutenrewardUiRewardButtonBinding

    private var buttonStyle = RewardButtonStyle.LIGHT

    @DrawableRes
    private var customButtonRes: Int = 0

    @DrawableRes
    private var defaultButtonRes = 0

    private var shouldShowBadge = true
    private var isBadgeSetVisibleByUser = true
    private var badgePosition = BadgePosition.TOP_RIGHT
    private var badgeLayoutSize = 0

    init {
        getAttributes(attrs)
        binding =
            RakutenrewardUiRewardButtonBinding.inflate(LayoutInflater.from(context), this, true)
        binding.badgeView.initBadgeView(badgeLayoutSize)
        initRewardButton()
    }

    private fun getAttributes(attrs: AttributeSet?) {
        //get layout size
        val attrsArray = intArrayOf(
            android.R.attr.layout_width,
            android.R.attr.layout_height
        )
        val layoutSizeArray = context.obtainStyledAttributes(attrs, attrsArray)
        try {
            val widthIndex = 0
            val heightIndex = 1
            val width = layoutSizeArray.getDimensionPixelSize(widthIndex, 0)
            val height = layoutSizeArray.getDimensionPixelSize(heightIndex, 0)
            badgeLayoutSize = min(width, height)
        } finally {
            layoutSizeArray.recycle()
        }

        context.theme.obtainStyledAttributes(attrs, R.styleable.RewardButton, 0, 0)
            .apply {
                try {
                    val buttonStyleIndex = getInteger(R.styleable.RewardButton_button_style, 0)
                    setButtonStyleFromAttribute(buttonStyleIndex)
                    isBadgeSetVisibleByUser = getBoolean(R.styleable.RewardButton_show_badge, true)
                    val badgePositionIndex = getInteger(R.styleable.RewardButton_badge_position, 0)
                    setBadgePositionFromAttribute(badgePositionIndex)
                } finally {
                    recycle()
                }
            }
    }

    private fun setButtonStyleFromAttribute(index: Int) {
        buttonStyle = when (index) {
            0 -> RewardButtonStyle.LIGHT
            1 -> RewardButtonStyle.DARK
            else -> RewardButtonStyle.LIGHT
        }
    }

    private fun setBadgePositionFromAttribute(index: Int) {
        badgePosition = when (index) {
            0 -> BadgePosition.TOP_RIGHT
            1 -> BadgePosition.TOP_LEFT
            2 -> BadgePosition.BOTTOM_LEFT
            3 -> BadgePosition.BOTTOM_RIGHT
            else -> BadgePosition.TOP_RIGHT
        }
    }

    private fun initRewardButton() {
        //init button in disabled state
        binding.btnReward.isEnabled = false
        binding.btnReward.alpha = 0.5f
        binding.btnReward.setOnClickListener {
            sendEvent()
            CoroutineScope(Dispatchers.Main).launch {
                InternalMissionSps.openSpsPortalWithoutResult()
            }
        }
        binding.btnReward.scaleType = ImageView.ScaleType.FIT_CENTER
        binding.btnReward.setBackgroundColor(Color.TRANSPARENT)
        setBackgroundColor(Color.TRANSPARENT)
        RewardButtonManager.registerButton(this)
        updateButtonImageDrawable()
        updateButtonImage()

        isEnabled = RakutenReward.status === RakutenRewardSDKStatus.ONLINE
    }

    private fun sendEvent() {
        val eventItem = EventItem.createItem(EventNames.CLICK_REWARD_BUTTON)
        SdkModuleApi.sendEvent(eventItem)
    }

    /**
     * set reward button style
     *
     * @param buttonStyle Either [RewardButtonStyle.DARK] or [RewardButtonStyle.LIGHT]
     */
    fun setButtonStyle(buttonStyle: RewardButtonStyle) {
        this.buttonStyle = buttonStyle
        updateButtonImageDrawable()
        updateButtonImage()
    }

    /**
     * set custom button image
     *
     * @param resourceId Image Resource ID
     */
    fun setCustomImage(@DrawableRes resourceId: Int) {
        customButtonRes = resourceId
        updateButtonImage()
    }

    /**
     * update default button image on style changed
     */
    private fun updateButtonImageDrawable() {
        defaultButtonRes = when (buttonStyle) {
            RewardButtonStyle.LIGHT -> R.drawable.rakutenreward_ic_reward_light
            RewardButtonStyle.DARK -> R.drawable.rakutenreward_ic_reward_dark
        }
    }

    /**
     * set button image
     * use custom image if available, otherwise fallback to default
     */
    private fun updateButtonImage() {
        if (customButtonRes != 0) {
            binding.btnReward.setImageResource(customButtonRes)
        } else {
            binding.btnReward.setImageResource(defaultButtonRes)
        }
    }

    /**
     * Set unclaimed number badge visible setting.
     * @param visible Whether the badge is visible or not
     */
    fun setBadgeVisible(visible: Boolean) {
        isBadgeSetVisibleByUser = visible
        updateButtonStatus()
    }

    /**
     * disable badge if reward button is disabled
     */
    private fun setShouldShowBadge(isEnable: Boolean) {
        shouldShowBadge = isEnable
    }

    /**
     * Set badge position.
     * @param position Badge position enumeration [BadgePosition]
     */
    fun setBadgePosition(position: BadgePosition) {
        badgePosition = position
        updateButtonStatus()
    }

    private fun updateLabelWithState() {
        val status = RewardButtonManager.labelState

        if (parent == null || binding.btnReward.parent == null || !shouldShowBadge || !isBadgeSetVisibleByUser) {
            binding.badgeView.hide()
            return
        }
        val unclaimed = RakutenReward.user.unclaimed
        if (status == RewardButtonManager.LabelState.LABEL_STATE_NORMAL) {
            if (unclaimed > 0) {
                binding.badgeView.setCount(unclaimed)
                showBadge()
            } else {
                binding.badgeView.hide()
            }
        } // Hidden
        else {
            binding.badgeView.hide()
        }
    }

    private fun updateButtonStatus() {
        Handler(context.mainLooper).post {
            updateLabelWithState()
        }
    }

    /**
     * Set button enabled.
     * @param isEnable Button setting
     */
    override fun setEnabled(isEnable: Boolean) {
        super.setEnabled(isEnable)

        setShouldShowBadge(isEnable)

        binding.btnReward.isEnabled = isEnabled
        binding.btnReward.alpha = if (isEnabled) 1.0f else 0.5f

        updateButtonStatus()
    }

    private fun showBadge() {
        binding.badgeView.setBadgePosition(badgePosition)
        binding.badgeView.setBadgeMargin(0, 0)
        val localTranslateAnimation =
            TranslateAnimation(0.0f, 0.0f, 0.0f, 8.0f)
        localTranslateAnimation.repeatMode = 2
        localTranslateAnimation.interpolator = BounceInterpolator()
        localTranslateAnimation.fillAfter = true
        localTranslateAnimation.duration = 400L
        binding.badgeView.show(localTranslateAnimation)
    }

    /**
     * Update RewardButton UI
     */
    override fun updateButton() {
        isEnabled = RakutenReward.status === RakutenRewardSDKStatus.ONLINE
        updateButtonStatus()
    }
}