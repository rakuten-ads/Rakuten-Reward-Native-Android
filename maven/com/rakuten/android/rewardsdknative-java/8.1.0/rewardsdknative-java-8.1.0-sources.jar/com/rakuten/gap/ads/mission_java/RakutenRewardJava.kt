package com.rakuten.gap.ads.mission_java

import android.app.Activity
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultCallback
import com.rakuten.gap.ads.mission_core.Failed
import com.rakuten.gap.ads.mission_core.RakutenAuth
import com.rakuten.gap.ads.mission_core.RakutenReward
import com.rakuten.gap.ads.mission_core.Success
import com.rakuten.gap.ads.mission_core.data.MissionAchievementData
import com.rakuten.gap.ads.mission_java.listeners.AuthMemberInfoCallback
import com.rakuten.gap.ads.mission_java.listeners.CustomClaimCallback
import com.rakuten.gap.ads.mission_java.listeners.GetMissionDetailsCallback
import com.rakuten.gap.ads.mission_java.listeners.GetMissionsCallback
import com.rakuten.gap.ads.mission_java.listeners.GetMissionsLiteCallback
import com.rakuten.gap.ads.mission_java.listeners.LogActionCallback
import com.rakuten.gap.ads.mission_java.listeners.MemberInfoCallback
import com.rakuten.gap.ads.mission_java.listeners.OpenPortalCallback
import com.rakuten.gap.ads.mission_java.listeners.PointHistoryCallback
import com.rakuten.gap.ads.mission_java.listeners.RequestForConsentCallback
import com.rakuten.gap.ads.mission_java.listeners.UnclaimedItemCallback
import com.rakuten.gap.ads.mission_ui.api.activity.openSDKPortal

/**
 * Java-compatible APIs for RakutenReward SDK
 * 
 * This class provides Java-style callback interfaces for Android projects written in Java
 * that need to use Rakuten Reward SDK functionality.
 * 
 * This is a wrapper around the core RakutenReward APIs, providing the same functionality
 * with a more Java-friendly interface.
 */
object RakutenRewardJava {

    /**
     * Log a mission action
     *
     * @param [actionCode] The action code of the mission
     * @param [callback] Callback for success/failure
     */
    @JvmStatic
    fun logAction(actionCode: String, callback: LogActionCallback) {
        RakutenReward.logAction(actionCode, {
            callback.success()
        }, { e ->
            callback.fail(e)
        })
    }

    /**
     * Get the latest member info
     * 
     * @param [callback] Callback for success/failure
     */
    @JvmStatic
    fun memberInfo(callback: MemberInfoCallback) {
        RakutenReward.memberInfo({ sdkuser ->
            callback.success(sdkuser)
        }, { e ->
            callback.fail(e)
        })
    }

    /**
     * Get the mission list
     * 
     * @param [callback] Callback for success/failure
     */
    @JvmStatic
    fun getMissions(callback: GetMissionsCallback) {
        RakutenReward.getMissions({ missions ->
            callback.success(missions)
        }, { e ->
            callback.fail(e)
        })
    }

    /**
     * Get the mission list in lite version.
     * Lite version of mission data only contain the necessary information for the mission.
     * It does not contain the progress of the mission.
     *
     * @param [callback] Callback for success/failure
     * @since 6.1.0
     */
    @JvmStatic
    fun getMissionsLite(callback: GetMissionsLiteCallback) {
        RakutenReward.getMissionsLite({ missions ->
            callback.success(missions)
        }, { e ->
            callback.fail(e)
        })
    }

    /**
     * Get the mission details
     *
     * @param [actionCode] The action code of the mission
     * @param [callback] Callback for success/failure
     * @since 6.1.0
     */
    @JvmStatic
    fun getMissionDetails(actionCode: String, callback: GetMissionDetailsCallback) {
        RakutenReward.getMissionDetails(actionCode, { mission ->
            callback.success(mission)
        }, { e ->
            callback.fail(e)
        })
    }

    /**
     * Get the list of unclaimed items
     * 
     * @param [callback] Callback for success/failure
     */
    @JvmStatic
    fun getUnclaimedItems(callback: UnclaimedItemCallback) {
        RakutenReward.getUnclaimedItems({ missions ->
            callback.success(missions)
        }, { e ->
            callback.failed(e)
        })
    }

    /**
     * Get user's last 3 months point history
     * 
     * @param [callback] Callback for success/failure
     */
    @JvmStatic
    fun getPointHistory(callback: PointHistoryCallback) {
        RakutenReward.getPointHistory({ pointHistory ->
            callback.success(pointHistory)
        }, { e ->
            callback.fail(e)
        })
    }

    /**
     * Request for Consent if the user have not provide consent.
     *
     * @param [callback] Optional callback for result
     * @since 4.0.0
     */
    @JvmStatic
    fun requestForConsent(callback: RequestForConsentCallback? = null) {
        RakutenReward.requestForConsent(callback?.let { cb ->
            { status ->
                cb.onRequestConsentResult(status)
            }
        })
    }

    /**
     * Show a notification banner if user haven't provide consent.
     *
     * @param [callback] Optional callback for result
     * @since 5.3.0
     */
    @JvmStatic
    fun showConsentBanner(callback: RequestForConsentCallback? = null) {
        RakutenReward.showConsentBanner(callback?.let { cb ->
            { status ->
                cb.onRequestConsentResult(status)
            }
        })
    }

    /**
     * Get user latest Rakuten Points and Rank.
     *
     * @param [callback] AuthMemberInfoCallback instance
     */
    @JvmStatic
    fun getUserInfo(callback: AuthMemberInfoCallback) {
        RakutenAuth.getUserInfo({ userInfo ->
            callback.success(userInfo)
        }, { e ->
            callback.fail(e)
        })
    }

    /**
     * Claim Point API for Java usage. Claim view will be displayed to show the claim status
     *
     * @param [missionData] MissionAchievementData instance to claim
     * @param [callback] CustomClaimCallback instance
     */
    @JvmStatic
    fun claimMissionItem(missionData: MissionAchievementData, callback: CustomClaimCallback) {
        missionData.claim({
            callback.success(it)
        }) {
            callback.fail(it)
        }
    }

    /**
     * Open SDK Portal UI
     *
     * @param [openPortalCallback] Callback to get the result of whether SDK portal is opened or not.
     * @param [requestCode] Request Code to handle SDK portal closed event in [Activity.onActivityResult]
     * @param [activityResultCallback] ActivityResultCallback to be triggered when SDK portal is closed.
     *
     */
    @JvmStatic
    fun openSDKPortal(
        openPortalCallback: OpenPortalCallback,
        requestCode: Int = 515,
        activityResultCallback: ActivityResultCallback<ActivityResult>? = null
    ) {
        RakutenReward.openSDKPortal({ result ->
            when (result) {
                is Failed -> openPortalCallback.failed(result.error)
                is Success -> openPortalCallback.success()
            }
        }, requestCode, activityResultCallback)
    }
}